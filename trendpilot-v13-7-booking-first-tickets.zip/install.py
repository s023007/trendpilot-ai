#!/usr/bin/env python3
"""Upgrade TrendPilot Tickets to V13.7 booking-first experience."""
from __future__ import annotations

import argparse
import json
import re
import shutil
from pathlib import Path
from urllib.parse import urlparse

VERSION = "13.7.0"
STYLE_TAG = '<link rel="stylesheet" href="/css/style-v13-7-ticket-booking.css?v=13.7.0">'
HOME_START = "<!-- TP_TICKETS_HOME_START -->"
HOME_END = "<!-- TP_TICKETS_HOME_END -->"

HOME_PROMO = f'''{HOME_START}
<section class="tp-ticket-home-promo-v137" aria-labelledby="tp-ticket-home-title"><div class="tp-ticket-home-promo-inner"><div><span class="tp-kicker">Tickets & experiences</span><h2 id="tp-ticket-home-title">Find the event. Choose the seat. Check the real price.</h2><p>Use a clearer booking route for football, Formula 1, concerts and theatre. TrendPilot helps users choose a sensible seat category before opening live provider listings.</p><div class="tp-ticket-home-promo-actions"><a class="tp-btn tp-btn-primary" href="/tickets/">Find tickets</a><a class="tp-btn tp-btn-light" href="/tickets/mens-nations-league/">Try the football seat helper</a></div></div><div class="tp-ticket-home-promo-card"><h3>Popular ticket starts</h3><div class="tp-home-ticket-links"><a href="/tickets/#ticket-finder">Search an event</a><a href="/tickets/#ticket-finder">Premier League</a><a href="/tickets/#ticket-finder">Formula 1</a><a href="/tickets/#ticket-finder">Concerts</a><a href="/tickets/#ticket-finder">Theatre</a><a href="/tickets/mens-nations-league/">Seat guide</a></div></div></div></section>
{HOME_END}'''


def valid_http_url(value: str) -> bool:
    try:
        parsed = urlparse(value.strip())
        return parsed.scheme in {"http", "https"} and bool(parsed.netloc)
    except Exception:
        return False


def existing_deeplink(root: Path) -> str:
    path = root / "data" / "tickets-config.js"
    if not path.exists():
        return ""
    text = path.read_text(encoding="utf-8", errors="ignore")
    match = re.search(r'sampleDeepLink:\s*"([^"]*)"', text)
    if not match:
        return ""
    value = match.group(1).replace(r"\u0026", "&")
    return value if valid_http_url(value) else ""


def copy_payload(package_root: Path, repo_root: Path) -> None:
    payload = package_root / "payload"
    if not payload.is_dir():
        raise FileNotFoundError(f"Payload folder not found: {payload}")
    for source in payload.rglob("*"):
        if source.is_dir():
            continue
        relative = source.relative_to(payload)
        destination = repo_root / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)


def inject_config(repo_root: Path, deeplink: str) -> None:
    path = repo_root / "data" / "tickets-config.js"
    text = path.read_text(encoding="utf-8")
    safe = json.dumps(deeplink, ensure_ascii=False)[1:-1]
    text = text.replace("__TICOMBO_SAMPLE_DEEPLINK__", safe)
    path.write_text(text, encoding="utf-8")


def ensure_style(text: str) -> str:
    if "style-v13-7-ticket-booking.css" in text:
        return text
    if "</head>" in text:
        return text.replace("</head>", STYLE_TAG + "</head>", 1)
    return text


def replace_or_insert_home_promo(repo_root: Path) -> bool:
    path = repo_root / "index.html"
    if not path.exists():
        return False
    text = path.read_text(encoding="utf-8", errors="ignore")
    original = text
    text = ensure_style(text)
    pattern = re.compile(re.escape(HOME_START) + r".*?" + re.escape(HOME_END), re.S)
    if pattern.search(text):
        text = pattern.sub(HOME_PROMO, text, count=1)
    elif "</main>" in text:
        text = text.replace("</main>", HOME_PROMO + "\n</main>", 1)
    if text != original:
        path.write_text(text, encoding="utf-8")
        return True
    return False


def patch_sitemap(repo_root: Path) -> bool:
    path = repo_root / "sitemap.xml"
    if not path.exists():
        return False
    text = path.read_text(encoding="utf-8", errors="ignore")
    changed = False
    for loc, priority in [
        ("https://trendpilot-ai.netlify.app/tickets/", "0.9"),
        ("https://trendpilot-ai.netlify.app/tickets/mens-nations-league/", "0.8"),
        ("https://trendpilot-ai.netlify.app/tickets/provider/ticombo/", "0.5"),
    ]:
        if loc not in text and "</urlset>" in text:
            text = text.replace("</urlset>", f"  <url><loc>{loc}</loc><changefreq>weekly</changefreq><priority>{priority}</priority></url>\n</urlset>", 1)
            changed = True
    if changed:
        path.write_text(text, encoding="utf-8")
    return changed


def write_status(repo_root: Path, deeplink_ready: bool, home_changed: bool, sitemap_changed: bool) -> None:
    status = {
        "version": VERSION,
        "feature": "Tickets booking-first UX",
        "installed": True,
        "ticomboTrackingReady": deeplink_ready,
        "consumerJourney": ["find event", "choose priority", "check live listing"],
        "liveCategories": ["football", "formula 1", "music", "theatre"],
        "homePromoUpdated": home_changed,
        "sitemapUpdated": sitemap_changed,
    }
    path = repo_root / "data" / "tickets-integration-status.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(status, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def validate(repo_root: Path, deeplink_ready: bool) -> None:
    required = [
        "tickets/index.html",
        "tickets/mens-nations-league/index.html",
        "tickets/provider/ticombo/index.html",
        "css/style-v13-7-ticket-booking.css",
        "js/tickets-v13-7.js",
        "data/tickets-config.js",
        "images/tickets/ticket-search.svg",
        "images/tickets/ticket-football.svg",
        "images/tickets/ticket-f1.svg",
        "images/tickets/ticket-music.svg",
        "images/tickets/ticket-theatre.svg",
        "images/tickets/stadium-seating.svg",
    ]
    missing = [item for item in required if not (repo_root / item).is_file()]
    if missing:
        raise RuntimeError(f"Missing installed files: {missing}")
    config = (repo_root / "data" / "tickets-config.js").read_text(encoding="utf-8")
    if "__TICOMBO_SAMPLE_DEEPLINK__" in config:
        raise RuntimeError("Ticombo placeholder was not replaced")
    if deeplink_ready and 'sampleDeepLink: "https' not in config:
        raise RuntimeError("Existing Ticombo deeplink was not preserved")
    hub = (repo_root / "tickets" / "index.html").read_text(encoding="utf-8")
    event = (repo_root / "tickets" / "mens-nations-league" / "index.html").read_text(encoding="utf-8")
    for token in ["What do you want to attend?", "data-booking-assistant", "data-ticket-destination=\"football\""]:
        if token not in hub:
            raise RuntimeError(f"Ticket hub validation failed: {token}")
    for token in ["Choose the match first", "data-seat-chooser", "See current matches and prices"]:
        if token not in event:
            raise RuntimeError(f"Event page validation failed: {token}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", default=".")
    parser.add_argument("--package-root", default=str(Path(__file__).resolve().parent))
    parser.add_argument("--ticombo-deeplink", default="", help="Optional replacement Admitad Ticombo deeplink; leave blank to preserve the existing one")
    args = parser.parse_args()

    repo_root = Path(args.repo).resolve()
    package_root = Path(args.package_root).resolve()
    if not (repo_root / ".git").exists() and not (repo_root / "index.html").exists():
        raise RuntimeError(f"The selected repository root does not look like TrendPilot: {repo_root}")

    supplied = args.ticombo_deeplink.strip()
    previous = existing_deeplink(repo_root)
    if supplied and not valid_http_url(supplied):
        raise ValueError("The Ticombo deeplink must be a complete http(s) URL")
    deeplink = supplied if valid_http_url(supplied) else previous

    copy_payload(package_root, repo_root)
    inject_config(repo_root, deeplink)
    home_changed = replace_or_insert_home_promo(repo_root)
    sitemap_changed = patch_sitemap(repo_root)
    write_status(repo_root, bool(deeplink), home_changed, sitemap_changed)
    validate(repo_root, bool(deeplink))

    print(json.dumps({
        "version": VERSION,
        "ticombo_tracking_ready": bool(deeplink),
        "home_promo_updated": home_changed,
        "sitemap_updated": sitemap_changed,
        "message": "TrendPilot V13.7 booking-first ticket experience installed successfully",
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
