TrendPilot AI — Admitad Coupon API V2
=====================================

هذه الحزمة تستخدم:
- ADMITAD_CLIENT_ID
- ADMITAD_CLIENT_SECRET

ولا تحتاج:
- base64_header
- رابط Export للكوبونات
- Secret ثالث لمعرّف الموقع

يتم اكتشاف مساحة TrendPilot AI تلقائياً، ثم جلب جميع الكوبونات والعروض
المتاحة لها من Admitad API، مع أكواد الخصم وروابط التتبع وتواريخ الصلاحية.

الملفات الناتجة:
- data/coupons.json
- data/coupon-report.json
- js/coupons-data.js

طريقة الرفع:
1. ارفع trendpilot-admitad-coupons-api-v2.zip إلى جذر المستودع.
2. ارفع update-admitad-coupons-api.yml داخل .github/workflows/ دون تغيير الاسم.
3. شغّل Action باسم Update Admitad Coupons API.
4. لا تشغّل Workflow القديم المبني على Export بعد نجاح هذا الإصدار.
