#!/usr/bin/env python3
"""Install TrendPilot V13.6 Tickets & Experiences into the current repository."""
from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
from pathlib import Path
from urllib.parse import urlparse

VERSION = "13.6.0"
STYLE_TAG = '<link rel="stylesheet" href="/css/style-v13-6-tickets.css?v=13.6.0">'
HOME_START = "<!-- TP_TICKETS_HOME_START -->"
HOME_END = "<!-- TP_TICKETS_HOME_END -->"
TICKET_LINK = '<a href="/tickets/">Tickets & experiences</a>'

HOME_PROMO = f'''{HOME_START}
<section class="tp-ticket-home-promo" aria-labelledby="tp-ticket-home-title"><div class="tp-ticket-home-promo-inner"><div><span class="tp-kicker">Tickets & experiences</span><h2 id="tp-ticket-home-title">Compare providers, seat zones and booking evidence.</h2><p>TrendPilot now helps users understand ticket-marketplace type, seating trade-offs, fees, delivery and buyer-protection checks before opening live availability.</p><div class="tp-ticket-home-promo-actions"><a class="tp-btn tp-btn-primary" href="/tickets/">Explore tickets</a><a class="tp-btn tp-btn-light" href="/tickets/mens-nations-league/">View the live example</a></div></div><div class="tp-ticket-home-promo-card"><span>First connected provider</span><h3>Ticombo</h3><p>Deep-linked competition access with transparent marketplace labelling and qualified outbound clicks.</p><ul><li>One event page can hold several providers</li><li>Seat-zone guidance before checkout</li><li>No automatic redirect from images</li><li>Ready for Feed, API or deep-link partners</li></ul></div></div></section>
{HOME_END}'''

TICKET_DISCLOSURE_START = "<!-- TP_TICKET_DISCLOSURE_START -->"
TICKET_DISCLOSURE = f'''{TICKET_DISCLOSURE_START}
<section class="tp-ticket-section"><div class="tp-shell"><div class="tp-ticket-section-head"><div><span class="tp-kicker">Ticket links</span><h2>How ticket-provider links work.</h2></div></div><div class="tp-ticket-decision-grid"><article><h3>Clear outbound action</h3><p>Event images and names open TrendPilot decision pages. A clearly labelled provider button is the action that leaves TrendPilot.</p></article><article><h3>Marketplace disclosure</h3><p>Official sellers and resale marketplaces are identified separately. A marketplace is not described as official without listing-level evidence.</p></article><article><h3>Affiliate relationship</h3><p>TrendPilot may earn a commission or qualifying referral payment from provider links. Organic comparison order is based on available booking evidence, not the highest payment.</p></article></div></div></section>'''

TICKET_METHOD_START = "<!-- TP_TICKET_METHOD_START -->"
TICKET_METHOD = f'''{TICKET_METHOD_START}
<section class="tp-ticket-section tp-ticket-soft"><div class="tp-shell"><div class="tp-ticket-section-head"><div><span class="tp-kicker">Ticket methodology</span><h2>How ticket offers will be compared.</h2></div><p>Ticket pages group the same event first, then compare provider type, total-cost evidence, seat information, delivery, protection, freshness and data completeness.</p></div><div class="tp-ticket-principles"><article><span>1</span><h3>Event identity</h3><p>Team or artist, date, venue and city must match before offers are grouped.</p></article><article><span>2</span><h3>Total-cost evidence</h3><p>Unknown mandatory fees prevent an offer from being labelled the cheapest final price.</p></article><article><span>3</span><h3>Provider type</h3><p>Official seller and resale marketplace labels remain visible.</p></article><article><span>4</span><h3>Freshness</h3><p>Prices and availability are not presented as current when live provider data is unavailable.</p></article></div></div></section>'''


def valid_http_url(value: str) -> bool:
    try:
        parsed = urlparse(value.strip())
        return parsed.scheme in {"http", "https"} and bool(parsed.netloc)
    except Exception:
        return False


def existing_deeplink(root: Path) -> str:
    path = root / "data" / "tickets-config.js"
    if not path.exists():
        return ""
    text = path.read_text(encoding="utf-8", errors="ignore")
    match = re.search(r'sampleDeepLink:\s*"([^"]*)"', text)
    if not match:
        return ""
    value = match.group(1).replace(r"\u0026", "&")
    return value if valid_http_url(value) else ""


def copy_payload(package_root: Path, repo_root: Path) -> None:
    payload = package_root / "payload"
    if not payload.is_dir():
        raise FileNotFoundError(f"Payload folder not found: {payload}")
    for source in payload.rglob("*"):
        if source.is_dir():
            continue
        relative = source.relative_to(payload)
        destination = repo_root / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)


def inject_config(repo_root: Path, deeplink: str) -> None:
    config_path = repo_root / "data" / "tickets-config.js"
    text = config_path.read_text(encoding="utf-8")
    safe = json.dumps(deeplink, ensure_ascii=False)[1:-1]
    text = text.replace("__TICOMBO_SAMPLE_DEEPLINK__", safe)
    config_path.write_text(text, encoding="utf-8")


def ensure_style(text: str) -> str:
    if "style-v13-6-tickets.css" in text:
        return text
    if "</head>" in text:
        return text.replace("</head>", f"{STYLE_TAG}</head>", 1)
    return text


def insert_ticket_link(text: str) -> tuple[str, bool]:
    if 'href="/tickets/"' in text or "href='/tickets/'" in text:
        return text, False

    replacements = [
        ('<a href="/rare-used/">Rare Finds</a><a href="/guides/">', f'<a href="/rare-used/">Rare Finds</a>{TICKET_LINK}<a href="/guides/">'),
        ('<a href="/rare-used/">Rare Finds</a><a href="/sourcing/">', f'<a href="/rare-used/">Rare Finds</a>{TICKET_LINK}<a href="/sourcing/">'),
        ('<a href="/software/">Software Finder</a><a href="/rare-used/">', f'<a href="/software/">Software Finder</a>{TICKET_LINK}<a href="/rare-used/">'),
        ('<a href="/products/">Electronics</a><a href="/sourcing/">', f'<a href="/products/">Electronics</a>{TICKET_LINK}<a href="/sourcing/">'),
        ('<a href="/products/">Electronics Lab</a><a href="/software/">', f'<a href="/products/">Electronics Lab</a>{TICKET_LINK}<a href="/software/">'),
    ]
    for old, new in replacements:
        if old in text:
            return text.replace(old, new, 1), True

    # Fallback: add before the main navigation action.
    nav_action = re.search(r'(<a\s+class="(?:tp-nav-cta|nav-action)"[^>]*>)', text)
    if nav_action:
        pos = nav_action.start()
        return text[:pos] + TICKET_LINK + text[pos:], True
    return text, False


def insert_footer_link(text: str) -> tuple[str, bool]:
    # A page can already have the nav link but not the footer link. Count occurrences.
    if text.count('href="/tickets/"') >= 2:
        return text, False
    candidates = [
        ('<a href="/rare-used/">Rare Finds</a><a href="/sourcing/">Business Sourcing</a>', '<a href="/rare-used/">Rare Finds</a><a href="/tickets/">Tickets & experiences</a><a href="/sourcing/">Business Sourcing</a>'),
        ('<a href="/rare-used/">Rare Finds</a><a href="/sourcing/">For business</a>', '<a href="/rare-used/">Rare Finds</a><a href="/tickets/">Tickets & experiences</a><a href="/sourcing/">For business</a>'),
        ('<a href="/products/">Electronics</a><a href="/sourcing/">For business</a>', '<a href="/products/">Electronics</a><a href="/tickets/">Tickets & experiences</a><a href="/sourcing/">For business</a>'),
    ]
    for old, new in candidates:
        if old in text:
            return text.replace(old, new, 1), True
    return text, False


def patch_html_files(repo_root: Path) -> dict[str, int]:
    stats = {"html_scanned": 0, "html_changed": 0, "nav_links_added": 0, "footer_links_added": 0}
    ignored_parts = {".git", "node_modules", ".trendpilot-v13-6"}
    for path in repo_root.rglob("*.html"):
        if ignored_parts.intersection(path.parts):
            continue
        stats["html_scanned"] += 1
        original = path.read_text(encoding="utf-8", errors="ignore")
        text = original
        text, nav_added = insert_ticket_link(text)
        text, footer_added = insert_footer_link(text)
        if nav_added:
            stats["nav_links_added"] += 1
        if footer_added:
            stats["footer_links_added"] += 1
        if path.resolve() == (repo_root / "index.html").resolve():
            text = ensure_style(text)
            if HOME_START not in text and "</main>" in text:
                text = text.replace("</main>", HOME_PROMO + "\n</main>", 1)
        if text != original:
            path.write_text(text, encoding="utf-8")
            stats["html_changed"] += 1
    return stats


def patch_trust_pages(repo_root: Path) -> dict[str, bool]:
    results = {"affiliate_disclosure": False, "editorial_methodology": False}
    targets = [
        (repo_root / "affiliate-disclosure.html", TICKET_DISCLOSURE_START, TICKET_DISCLOSURE, "affiliate_disclosure"),
        (repo_root / "editorial-methodology.html", TICKET_METHOD_START, TICKET_METHOD, "editorial_methodology"),
    ]
    for path, marker, block, key in targets:
        if not path.exists():
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        original = text
        text = ensure_style(text)
        if marker not in text and "</main>" in text:
            text = text.replace("</main>", block + "\n</main>", 1)
        if text != original:
            path.write_text(text, encoding="utf-8")
            results[key] = True
    return results


def patch_sitemap(repo_root: Path) -> bool:
    path = repo_root / "sitemap.xml"
    if not path.exists():
        return False
    text = path.read_text(encoding="utf-8", errors="ignore")
    if "https://trendpilot-ai.netlify.app/tickets/" in text:
        return False
    block = """
  <url><loc>https://trendpilot-ai.netlify.app/tickets/</loc><changefreq>weekly</changefreq><priority>0.8</priority></url>
  <url><loc>https://trendpilot-ai.netlify.app/tickets/mens-nations-league/</loc><changefreq>daily</changefreq><priority>0.8</priority></url>
  <url><loc>https://trendpilot-ai.netlify.app/tickets/provider/ticombo/</loc><changefreq>monthly</changefreq><priority>0.6</priority></url>
"""
    if "</urlset>" not in text:
        return False
    path.write_text(text.replace("</urlset>", block + "</urlset>", 1), encoding="utf-8")
    return True


def write_status(repo_root: Path, deeplink_ready: bool, stats: dict[str, int], sitemap_changed: bool, trust_pages: dict[str, bool]) -> None:
    status = {
        "version": VERSION,
        "feature": "Tickets & Experiences",
        "installed": True,
        "ticomboTrackingReady": deeplink_ready,
        "initialCompetition": "Men's Nations League",
        "providerArchitecture": ["feed", "api", "deeplink", "manual"],
        "htmlPatchStats": stats,
        "sitemapUpdated": sitemap_changed,
        "trustPagesUpdated": trust_pages,
    }
    (repo_root / "data" / "tickets-integration-status.json").write_text(
        json.dumps(status, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )


def validate(repo_root: Path, deeplink_ready: bool) -> None:
    required = [
        "tickets/index.html",
        "tickets/mens-nations-league/index.html",
        "tickets/provider/ticombo/index.html",
        "css/style-v13-6-tickets.css",
        "js/tickets-v13-6.js",
        "data/tickets-config.js",
        "images/tickets/tickets-hero.svg",
        "images/tickets/stadium-seating.svg",
    ]
    missing = [item for item in required if not (repo_root / item).is_file()]
    if missing:
        raise RuntimeError(f"Missing installed files: {missing}")
    config = (repo_root / "data" / "tickets-config.js").read_text(encoding="utf-8")
    if "__TICOMBO_SAMPLE_DEEPLINK__" in config:
        raise RuntimeError("Ticombo placeholder was not replaced")
    if deeplink_ready and "sampleDeepLink: \"https" not in config:
        raise RuntimeError("Supplied Ticombo deeplink was not stored")
    event_page = (repo_root / "tickets" / "mens-nations-league" / "index.html").read_text(encoding="utf-8")
    for token in ["data-ticket-outbound", "Ticket marketplace", "Check live tickets", "sponsored nofollow noopener"]:
        if token == "sponsored nofollow noopener":
            # This token is applied at runtime by JS, not hard-coded into the HTML.
            continue
        if token not in event_page:
            raise RuntimeError(f"Event page validation failed: {token}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", default=".", help="Repository root")
    parser.add_argument("--package-root", default=str(Path(__file__).resolve().parent), help="Extracted package root")
    parser.add_argument("--ticombo-deeplink", default="", help="A full Admitad Ticombo sample/default deeplink")
    args = parser.parse_args()

    repo_root = Path(args.repo).resolve()
    package_root = Path(args.package_root).resolve()
    if not (repo_root / ".git").exists() and not (repo_root / "index.html").exists():
        raise RuntimeError(f"The selected repository root does not look like TrendPilot: {repo_root}")

    supplied = args.ticombo_deeplink.strip()
    previous = existing_deeplink(repo_root)
    deeplink = supplied if valid_http_url(supplied) else previous
    if supplied and not valid_http_url(supplied):
        raise ValueError("The Ticombo deeplink must be a complete http(s) URL")

    copy_payload(package_root, repo_root)
    inject_config(repo_root, deeplink)
    stats = patch_html_files(repo_root)
    trust_pages = patch_trust_pages(repo_root)
    sitemap_changed = patch_sitemap(repo_root)
    write_status(repo_root, bool(deeplink), stats, sitemap_changed, trust_pages)
    validate(repo_root, bool(deeplink))

    print(json.dumps({
        "version": VERSION,
        "ticombo_tracking_ready": bool(deeplink),
        "html": stats,
        "sitemap_updated": sitemap_changed,
        "trust_pages": trust_pages,
        "message": "TrendPilot Tickets & Experiences installed successfully",
    }, indent=2))
    if not deeplink:
        print("WARNING: No Admitad Ticombo deeplink was supplied. Public buttons will use direct Ticombo destinations until the installer is rerun with the link.", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
